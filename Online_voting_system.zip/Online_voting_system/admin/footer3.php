	  <hr>

      <footer>
        <div class="foot_center3"><p>Copyright &copy; D.G.Tatkare Mahavidyalay Mangaon</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: Ansh Sawant :-P</p>
		</div>
      </footer>